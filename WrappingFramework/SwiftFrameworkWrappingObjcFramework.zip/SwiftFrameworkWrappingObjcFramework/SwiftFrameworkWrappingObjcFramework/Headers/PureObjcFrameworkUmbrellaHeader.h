//
//  PureObjcFrameworkUmbrellaHeader.h
//  PureObjcFrameworkUmbrellaHeader
//
//  Created by hanwe lee on 2020/11/18.
//  Copyright © 2020 hanwe lee. All rights reserved.
//

#ifndef PureObjcFrameworkUmbrellaHeader_h
#define PureObjcFrameworkUmbrellaHeader_h

#import "../Framework/PureObjcFramework.framework/Headers/PureObjcFramework.h"

#endif /* PureObjcFrameworkUmbrellaHeader_h */
