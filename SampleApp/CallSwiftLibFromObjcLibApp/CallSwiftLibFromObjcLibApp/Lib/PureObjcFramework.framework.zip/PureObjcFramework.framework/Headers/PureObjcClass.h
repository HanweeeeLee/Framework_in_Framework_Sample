//
//  PureObjcClass.h
//  PureObjcFramework
//
//  Created by hanwe lee on 2020/11/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PureObjcClass : NSObject

-(void) pureObjcTestFunc;

@end

NS_ASSUME_NONNULL_END
